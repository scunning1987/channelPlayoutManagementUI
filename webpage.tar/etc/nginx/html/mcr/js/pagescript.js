//pagescript.js

//hls url
var hlsURL = "http://myserver33/myindex.m3u8"

//apiendpointurl
const apiendpointurl = "https://7h8bbsirvf.execute-api.us-west-2.amazonaws.com/eng/"

//// Dont Touch Anything Below This Line ////

// hls player
var player = videojs('hlsplayer');

function hlsPlayerLoad() {
  document.getElementById('player2').innerHTML = '<video-js id="hlsplayer" class="vjs-default-skin" controls preload="auto" width="640" height="360"><source src=hlsURL type="application/x-mpegURL"></video-js>';
}

document.getElementById('button1').onclick = function() {
  displaymcrbody();
}
document.getElementById('button2').onclick = function() {
  displayeventsbody();
}
document.getElementById('button3').onclick = function() {
  displayanalyticsbody();
}
var playerinitnumber = 1
// body display change
function displaymcrbody(){

   var playerno = Math.floor(Math.random() * 100);
   var hlsPlayer = "hlsplayer" + playerno;
   document.getElementById("mcrbody").style.display = "block";
   document.getElementById("eventsbody").style.display = "none";
   document.getElementById("analyticsbody").style.display = "none";
   document.getElementById("button1").style.background = "rgb(179, 107, 0)";
   document.getElementById("button2").style.background = "rgb(255, 128, 0)";
   document.getElementById("button3").style.background = "rgb(255, 128, 0)";
   document.getElementById('player2').innerHTML = '<video-js id='+hlsPlayer+'  class="vjs-default-skin" controls preload="auto" width="640" height="360"><source src="http://myserver33/myindex.m3u8" type="application/x-mpegURL"></video-js>';
   document.getElementById('player1').innerHTML = '<object type="application/x-shockwave-flash" id="SampleMediaPlayback" name="SampleMediaPlayback" align="middle" data="js/SampleMediaPlayback.swf" width="640" height="360"><param name="quality" value="high"><param name="bgcolor" value="#000000"><param name="allowscriptaccess" value="sameDomain"><param name="allowfullscreen" value="true"><param name="flashvars" value="src=rtmp://34.218.208.141:1935/live/mcrview&amp;streamType=live&amp;autoPlay=true&amp;controlBarAutoHide=true&amp;controlBarPosition=bottom"></object>';
   var player = videojs(hlsPlayer);
}
function displayeventsbody(){
   document.getElementById("mcrbody").style.display = "none";
   document.getElementById("eventsbody").style.display = "block";
   document.getElementById("analyticsbody").style.display = "none";
   document.getElementById("button1").style.background = "rgb(255, 128, 0)";
   document.getElementById("button2").style.background = "rgb(179, 107, 0)";
   document.getElementById("button3").style.background = "rgb(255, 128, 0)";
   document.getElementById('player2').innerHTML = '';
   document.getElementById('player1').innerHTML = '';
}
function displayanalyticsbody(){
   document.getElementById("mcrbody").style.display = "none";
   document.getElementById("eventsbody").style.display = "none";
   document.getElementById("analyticsbody").style.display = "block";
   document.getElementById("button1").style.background = "rgb(255, 128, 0)";
   document.getElementById("button2").style.background = "rgb(255, 128, 0)";
   document.getElementById("button3").style.background = "rgb(179, 107, 0)";
   document.getElementById('player2').innerHTML = '';
   document.getElementById('player1').innerHTML = '';
   document.getElementById('telemembed').innerHTML = '<iframe src="http://ec2-35-166-173-36.us-west-2.compute.amazonaws.com/_plugin/kibana/app/kibana#/dashboard/a71f1cc0-6a0b-11ea-b3c3-bfce4d07d4cc?embed=true&_g=(refreshInterval%3A(pause%3A!f%2Cvalue%3A60000)%2Ctime%3A(from%3Anow-15m%2Cmode%3Aquick%2Cto%3Anow))" height="680" width="1350"></iframe>';
}

document.getElementById('assetdropdownbutton').onclick = function() {
  var bucket = document.getElementById("bucketname").value;
  var apiendpoint = apiendpointurl+'s3-getassets?';
  s3getObjectsAPI(bucket, apiendpoint);
}

function s3getObjectsAPI(bucket, apiendpoint) {

var url = apiendpoint+'bucket='+bucket;

let dropdown = document.getElementById('assetdropdownselect');
dropdown.length = 0;

let defaultOption = document.createElement('option');
defaultOption.text = 'Choose Asset';

dropdown.add(defaultOption);
dropdown.selectedIndex = 0;

var request = new XMLHttpRequest();
request.open('GET', url, true);

request.onload = function() {
  if (request.status === 200) {
    const data = JSON.parse(request.responseText);
    let option;
    for (let i = 0; i < data.length; i++) {
      option = document.createElement('option');
      option.text = data[i].name;
      option.value = data[i].key;
      dropdown.add(option);
    }
   } else {
    // Reached the server, but it returned an error
  }
}

request.onerror = function() {
  console.error('An error occurred fetching the JSON from ' + url);
};

request.send();
}

var takeType;

document.getElementById('takeimmediatebutton').onclick = function() {
  immButtonEnhance()
  takeType = 1;
}
document.getElementById('takenextbutton').onclick = function() {
  nextButtonEnhance()
  takeType = 2;
}
document.getElementById('takelastbutton').onclick = function() {
  lastButtonEnhance()
  takeType = 3;
}
document.getElementById('takecustombutton').onclick = function() {
  customButtonEnhance()
  takeType = 4;
  emlGetSchedule();
}
document.getElementById('schedulerefresh').onclick = function() {
  emlGetSchedule();
}

////
function emlGetSchedule(){
  var channelid = document.getElementById("channelid").value;
  var apiendpoint = apiendpointurl+"eml-getschedule?";

  var url = apiendpoint+'channelid='+channelid+"&maxresults=300";

let scheddropdown = document.getElementById('scheduledropdownselect');
scheddropdown.length = 0;

let scheddefaultOption = document.createElement('option');
scheddefaultOption.text = 'Choose Action To Follow';

var schedule = []

scheddropdown.add(scheddefaultOption);
scheddropdown.selectedIndex = 0;

var request = new XMLHttpRequest();
request.open('GET', url, true);

request.onload = function() {
  if (request.status === 200) {
    var data = JSON.parse(request.responseText);
    let option;
    for (let i = 0; i < data.length; i++) {
      option = document.createElement('option');
      option.text = data[i].actionname;
      option.value = data[i].actionname;
      schedule.push(data[i].actionname);
      //schedule.push('<br>');
      scheddropdown.add(option);
    }
   } else {
    // Reached the server, but it returned an error
  }
//document.getElementById("schedulelist").innerHTML = '<p>'+schedule.replace(",","")+'</p>';
schedulestring = schedule.toString();
document.getElementById("schedulelist").innerHTML = '<p>'+schedulestring.replace(/,/g,"<br>")+'</p>';
}

request.onerror = function() {
  console.error('An error occurred fetching the JSON from ' + url);
};

request.send();

}

////

document.getElementById('takeconfirmbutton').onclick = function() {
  document.getElementById("takeconfirmbutton").classList.add('pressedButton');
  fileslash = document.getElementById('assetdropdownselect').value;
  file = fileslash.replace(/\//g,"%2F");
  channelid = document.getElementById('channelid').value;
  bucket = document.getElementById('bucketname').value;
  alerttext = "channelid : " + channelid + "\nbucket : " + bucket + "\nfile : " + file;

  // if follow/append (type 2 or 3) is selected, do apiGET on currentActiveInput and use as variable
  // if custom type is selected, do a getElementbyId of user selected input

  // apiPutAction()

var enhancebutname;

  switch(takeType) {
  case 1:
    //alert(alerttext + "\nIMMEDIATE");
    apiPutAction(file, channelid, bucket, "eml-immediateswitch", "", 200);
    enhancebutname = "takeimmediatebutton";
    break;
  case 2:
    //alert(alerttext + "\nFOLLOW");
    apiPutAction(file, channelid, bucket, "eml-followcurrent", "", 200);
    enhancebutname = "takenextbutton";
    break;
  case 3:
    //alert(alerttext + "\nAPPEND");
    apiPutAction(file, channelid, bucket, "eml-followlast", "", 200);
    enhancebutname = "takelastbutton";
    break;
  case 4:
    //alert(alerttext + "\nCUSTOM");
    follow = document.getElementById('scheduledropdownselect').value;
    apiPutAction(file, channelid, bucket, "eml-followcustom", follow, 200);
    enhancebutname = "takecustombutton";
    break;
  default:
    alert("WARNING: You didn't select a TAKE TYPE!")
} 
fadeAway(enhancebutname, "takeconfirmbutton");//timer to remove css styling
emlGetSchedule();
takeType = 0;

}

function apiPutAction(file, channelid, bucket, takeType, follow, maxresults){
var lambdafunction = takeType;
var param1 = "input="+file;
var param2 = "&channelid="+channelid;
var param3 = "&bucket="+bucket;
var param4 = "&maxresults="+maxresults
var param5 = "&follow="+follow;

var apiEndpoint = apiendpointurl+lambdafunction+"?"+param1+param2+param3+param4+param5;
var putReq = new XMLHttpRequest();
putReq.open("PUT", apiEndpoint, false);
putReq.setRequestHeader("Accept","*/*");
putReq.send();
}

function immButtonEnhance(){
  document.getElementById("takeimmediatebutton").classList.add('pressedButton');
  document.getElementById("takenextbutton").classList.remove('pressedButton');
  document.getElementById("takelastbutton").classList.remove('pressedButton');
  document.getElementById("takecustombutton").classList.remove('pressedButton');
  document.getElementById("takeconfirmbutton").classList.remove('pressedButton');
}
function nextButtonEnhance(){
  document.getElementById("takeimmediatebutton").classList.remove('pressedButton');
  document.getElementById("takenextbutton").classList.add('pressedButton');
  document.getElementById("takelastbutton").classList.remove('pressedButton');
  document.getElementById("takecustombutton").classList.remove('pressedButton');
  document.getElementById("takeconfirmbutton").classList.remove('pressedButton');
}
function lastButtonEnhance(){
  document.getElementById("takeimmediatebutton").classList.remove('pressedButton');
  document.getElementById("takenextbutton").classList.remove('pressedButton');
  document.getElementById("takelastbutton").classList.add('pressedButton');
  document.getElementById("takecustombutton").classList.remove('pressedButton');
  document.getElementById("takeconfirmbutton").classList.remove('pressedButton');
}
function customButtonEnhance(){
  document.getElementById("takeimmediatebutton").classList.remove('pressedButton');
  document.getElementById("takenextbutton").classList.remove('pressedButton');
  document.getElementById("takelastbutton").classList.remove('pressedButton');
  document.getElementById("takecustombutton").classList.add('pressedButton');
  document.getElementById("takeconfirmbutton").classList.remove('pressedButton');
}


var fadeAway = function(subbuttonname, takebuttonname) {
  setTimeout(function(){
  document.getElementById(subbuttonname).classList.remove('pressedButton');
  document.getElementById(takebuttonname).classList.remove('pressedButton');
 }, 2000);
}

// Original code #########################################

var slateVar;
var adVar;
var sourceVar;

document.getElementById('adbreak1').onclick = function() {
  adbreak1Enhance();
  adVar = 1;
}
document.getElementById('adbreak2').onclick = function() {
  adbreak2Enhance();
  adVar = 2;
}
document.getElementById('adbreak3').onclick = function() {
  adbreak3Enhance();
  adVar = 3;
}

document.getElementById('switchbutton1').onclick = function() {
  switchButton1Enhance();
  sourceVar = 1;
}
document.getElementById('switchbutton2').onclick = function() {
  switchButton2Enhance();
  sourceVar = 2;
}
document.getElementById('switchbutton3').onclick = function() {
  switchButton3Enhance();
  sourceVar = 3;
}

function adbreak1Enhance(){
  document.getElementById("adbreak1").classList.add('pressedButton');
  document.getElementById("adbreak2").classList.remove('pressedButton');
  document.getElementById("adbreak3").classList.remove('pressedButton');
}

function adbreak2Enhance(){
  document.getElementById("adbreak2").classList.add('pressedButton');
  document.getElementById("adbreak1").classList.remove('pressedButton');
  document.getElementById("adbreak3").classList.remove('pressedButton');
}

function adbreak3Enhance(){
  document.getElementById("adbreak3").classList.add('pressedButton');
  document.getElementById("adbreak2").classList.remove('pressedButton');
  document.getElementById("adbreak1").classList.remove('pressedButton');
}

function switchButton1Enhance(){
  document.getElementById("switchbutton1").classList.add('pressedButton');
  document.getElementById("switchbutton2").classList.remove('pressedButton');
  document.getElementById("switchbutton3").classList.remove('pressedButton');
}

function switchButton2Enhance(){
  document.getElementById("switchbutton2").classList.add('pressedButton');
  document.getElementById("switchbutton1").classList.remove('pressedButton');
  document.getElementById("switchbutton3").classList.remove('pressedButton');
}

function switchButton3Enhance(){
  document.getElementById("switchbutton3").classList.add('pressedButton');
  document.getElementById("switchbutton2").classList.remove('pressedButton');
  document.getElementById("switchbutton1").classList.remove('pressedButton');
}

document.getElementById('takebutton1').onclick = function() {
  document.getElementById("takebutton1").classList.add('pressedButton');

 switch(sourceVar) {
  case 1:
    apiPut("https://xvsx891gz9.execute-api.us-west-2.amazonaws.com/Prod/input1");
    alert("Switched Source To SLATE 1");
    break;
  case 2:
    apiPut("https://xvsx891gz9.execute-api.us-west-2.amazonaws.com/Prod/input2");
    alert("Switched Source To : SLATE 2");
    break;
  case 3:
    apiPut("https://xvsx891gz9.execute-api.us-west-2.amazonaws.com/Prod/input3");
    alert("Switched Source To : LIVE SOURCE!");
    break;
  default:
    alert("WARNING: You didn't select a SOURCE!")
}
  fadeAway("switchbutton", sourceVar, "1");//timer to remove css styling
  sourceVar = 0;
}

document.getElementById('takebutton2').onclick = function() {
  document.getElementById("takebutton2").classList.add('pressedButton');

switch(adVar) {
  case 1:
    apiPut("https://p1k1nix8o4.execute-api.us-west-2.amazonaws.com/default/scte35inject15second");
    alert("15 Second Ad Break Inserted!");
    break;
  case 2:
    apiPut("https://8xivgo7r3l.execute-api.us-west-2.amazonaws.com/default/scte35inject30second");
    alert("30 Second Ad Break Inserted!");
    break;
  case 3:
    apiPut("https://smxpbp6e21.execute-api.us-west-2.amazonaws.com/default/scte35inject60second");
    alert("60 Second Ad Break Inserted!");
    break;
  default:
    alert("WARNING: You didn't select an Ad Duration!")
}
  fadeAway("adbreak", adVar, "2");//timer to remove css styling
  adVar = 0;
}

var apiPut = function(apiEndpoint) {

var putReq = new XMLHttpRequest();
putReq.open("OPTIONS", apiEndpoint, true);
putReq.setRequestHeader("Accept","*/*");
putReq.send();
}
