import json
import boto3
import datetime
import random

def lambda_handler(event, context):
    client = boto3.client('medialive')
    channelid = event['channelid']
    bucket = event['bucket']
    maxresults = int(event['maxresults'])
    inputkey = event['input'].replace("%2F","/")
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    actionname = inputkey.rsplit('/', 1)[-1] + "_" + timestring
    inputurl = bucket + "/" + str(inputkey)
    random_dyn_number = random.randint(5,8)
    inputattachref = "dynamic-00" + str(random_dyn_number)

    # GET ACTIVE ACTION (get from user input, not actual active)
    current_active = event['follow']

    # Get GET EML SCHEDULE
    try:
        response = client.describe_schedule(
        ChannelId=channelid,
        MaxResults=maxresults
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)

    schedule = []
    actionpaths = []
    for action in response['ScheduleActions']:
    #    schedule.update({action['ActionName'] : action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0]})
    #    schedule.append({'actionname' : action['ActionName'], 'url' : action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0]}) ## good array
    #    schedule.append({action['ActionName'] : action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0]}) ## good array
        schedule.append(action['ActionName'])
        #scheduledic.update({action['ActionName'] : action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0]})
        actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0])
    #return(schedule)
    
    # FIND WHERE ACTIVE ACTION IS IN CURRENT SCHEDULE
    # current_active (name of action)
    # schedule (list containing schedule of actions)
    # actionpaths (urls of actions to reassign) - this list needs to be used after the immediate put is complete

    indexofactive = schedule.index(current_active) + 1
    listlength = len(schedule) + 1

    # CREATE SUB ARRAY FOR ACTIONS TO REPOPULATE
    #return("Active item is : " + str(indexofactive) + "of" + str(listlength) + " items" + str(itemstoreschedule))
    itemstoreschedule = actionpaths[indexofactive:listlength] 
    itemstodelete = schedule[indexofactive:listlength] 

    deletedict = dict()
    deletedict["ActionNames"] = itemstodelete
    print(deletedict)
    
    # DELETE Items is subarray
    #actionstodelete = ' , '.join('"' + action + '"' for action in actions[0:deleteindex])
    #return actionstodelete
    try:
        response = client.batch_update_schedule(ChannelId=channelid,Deletes=deletedict)
    except Exception as e:
        return e
    print("made it to put the user specified file")
    # PUT user "input" to append selected item to "follow"
    custom_selection = event['follow']
    try:
        response = client.batch_update_schedule(
            ChannelId=channelid,
            Creates={
                'ScheduleActions': [
                    {
                        'ActionName': actionname,
                        'ScheduleActionSettings': {
                            'InputSwitchSettings': {
                                'InputAttachmentNameReference': inputattachref,
                                'UrlPath': [
                                    inputurl,inputurl
                                ]
                            },
                        },
                        'ScheduleActionStartSettings': {
                            'FollowModeScheduleActionStartSettings': {
                                'FollowPoint': 'END',
                                'ReferenceActionName': custom_selection
                    },
        
                        }
                    },
                ]
            }
        )
        #print(json.dumps(response))
    except Exception as e:
        print("Error creating Schedule Action")
        print(e)

    # PUT For each file left in Sub ARRAY DOOOO
    # list variable name : itemstoreschedule
    
    for item in itemstoreschedule:
        print(item)
        time = datetime.datetime.utcnow()
        timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
        actionname = item.rsplit('/', 1)[-1] + "_" + timestring
        inputurl = item
        random_dyn_number = random.randint(5,8)
        inputattachref = "dynamic-00" + str(random_dyn_number)

        # API Get schedule last action [swith action]
        
        try:
            response = client.describe_schedule(
            ChannelId=channelid,
            MaxResults=200
            )
        except Exception as e:
            print(e)
        custom_selection = response['ScheduleActions'][-1]['ActionName']
        
        # API Append Schedule with follow PUT
        
        try:
            response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref,
                                    'UrlPath': [
                                        inputurl,inputurl
                                    ]
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'FollowModeScheduleActionStartSettings': {
                                    'FollowPoint': 'END',
                                    'ReferenceActionName': custom_selection
                        },
            
                            }
                        },
                    ]
                }
            )
            print(json.dumps(response))
        except Exception as e:
            print("Error creating Schedule Action")
            print(e)
    return "done"