import json
import boto3
import datetime
import random

# Step 1 : Get current schedule
# Step 2 : isolate last item in schedule
# Step 3 : API call to follow last item in schedule

def lambda_handler(event, context):
    channelid = event['channelid']
    client = boto3.client('medialive')
    try:
        response = client.describe_schedule(
        ChannelId=channelid,
        MaxResults=200
        )
    except Exception as e:
        print(e)
    #custom_selection = response['ScheduleActions'][-1]['ActionName']
    schedule = []

    for action in response['ScheduleActions']:
        if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
            schedule.append(action['ActionName'])

    custom_selection = schedule[-1]
    
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    
    bucket = event['bucket']
    inputkey = str(event['input']).replace("%2F","/")
    actionname = inputkey.rsplit('/', 1)[-1] + "_" + timestring
    inputurl = bucket + "/" + inputkey
    random_dyn_number = random.randint(6,8)
    inputattachref = "dynamic-00" + str(random_dyn_number)
    client = boto3.client('medialive')
    try:
        response = client.batch_update_schedule(
            ChannelId=channelid,
            Creates={
                'ScheduleActions': [
                    {
                        'ActionName': actionname,
                        'ScheduleActionSettings': {
                            'InputSwitchSettings': {
                                'InputAttachmentNameReference': inputattachref,
                                'UrlPath': [
                                    inputurl,inputurl
                                ]
                            },
                        },
                        'ScheduleActionStartSettings': {
                            'FollowModeScheduleActionStartSettings': {
                                'FollowPoint': 'END',
                                'ReferenceActionName': custom_selection
                    },
        
                        }
                    },
                ]
            }
        )
        print(json.dumps(response))
    except Exception as e:
        print("Error creating Schedule Action")
        print(e)
    return response
