import json
import boto3
import datetime
import random

def lambda_handler(event, context):
    client = boto3.client('medialive')
    channelid = event['channelid']
    bucket = event['bucket']
    maxresults = int(event['maxresults'])
    inputkey = event['input'].replace("%2F","/")
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    actionname = inputkey.rsplit('/', 1)[-1] + "_" + timestring
    inputurl = bucket + "/" + str(inputkey)
    response = client.list_inputs(MaxResults=maxresults)
    inputs = []
    for channel in response['Inputs']:
        attachedchannelid = str(channel['AttachedChannels'])
        if channelid in attachedchannelid:
            if "DYNAMIC" in channel['InputSourceType']:
                inputs.append(channel['Name'])
    if len(inputs) is 0:
        return "ERROR: No dynamic inputs attached to this channel!"
    attacheddynamicinputs = len(inputs) -1
    inputattachref = str(inputs[random.randint(0,attacheddynamicinputs)])

    # GET ACTIVE ACTION
    try:
        response = client.describe_channel(
        ChannelId=channelid
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)
    current_active = response['PipelineDetails'][0]['ActiveInputSwitchActionName']

    # Get GET EML SCHEDULE
    try:
        response = client.describe_schedule(
        ChannelId=channelid,
        MaxResults=maxresults
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)

    schedule = []
    actionpaths = []
    for action in response['ScheduleActions']:
        if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
            schedule.append(action['ActionName'])
            if str(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']) in inputs:
                actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0])
            else:
                actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference'])    
    
    # FIND WHERE ACTIVE ACTION IS IN CURRENT SCHEDULE
    # current_active (name of action)
    # schedule (list containing schedule of actions)
    # actionpaths (urls of actions to reassign) - this list needs to be used after the immediate put is complete

    indexofactive = schedule.index(current_active) + 1
    listlength = len(schedule) + 1

    # CREATE SUB ARRAY FOR ACTIONS TO REPOPULATE
    #return("Active item is : " + str(indexofactive) + "of" + str(listlength) + " items" + str(itemstoreschedule))
    itemstoreschedule = actionpaths[indexofactive:listlength] 
    itemstodelete = schedule[indexofactive:listlength] 
    
    deletedict = dict()
    deletedict["ActionNames"] = itemstodelete
    
    # DELETE Items in subarray
    #actionstodelete = ' , '.join('"' + action + '"' for action in actions[0:deleteindex])
    #return actionstodelete
    try:
        response = client.batch_update_schedule(ChannelId=channelid,Deletes=deletedict)
    except Exception as e:
        return e

    # PUT user "input" to append selected item to "follow"
    custom_selection = current_active
    try:
        response = client.batch_update_schedule(
            ChannelId=channelid,
            Creates={
                'ScheduleActions': [
                    {
                        'ActionName': actionname,
                        'ScheduleActionSettings': {
                            'InputSwitchSettings': {
                                'InputAttachmentNameReference': inputattachref,
                                'UrlPath': [
                                    inputurl,inputurl
                                ]
                            },
                        },
                        'ScheduleActionStartSettings': {
                            'FollowModeScheduleActionStartSettings': {
                                'FollowPoint': 'END',
                                'ReferenceActionName': custom_selection
                    },
        
                        }
                    },
                ]
            }
        )
        #print(json.dumps(response))
    except Exception as e:
        print("Error creating Schedule Action")
        print(e)

    # PUT For each file left in Sub ARRAY DOOOO
    # list variable name : itemstoreschedule
    
    for item in itemstoreschedule:
        print(item)
        time = datetime.datetime.utcnow()
        timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
        actionname = item.rsplit('/', 1)[-1] + "_" + timestring
        inputurl = item
        inputattachref = str(inputs[random.randint(0,attacheddynamicinputs)])


        # API Get schedule last action [switch action]
        
        try:
            response = client.describe_schedule(
            ChannelId=channelid,
            MaxResults=200
            )
        except Exception as e:
            print(e)
        schedule = []

        for action in response['ScheduleActions']:
            if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
                schedule.append(action['ActionName'])

        custom_selection = schedule[-1]
        
        # API Append Schedule with follow PUT
        
        try:
            response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref,
                                    'UrlPath': [
                                        inputurl,inputurl
                                    ]
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'FollowModeScheduleActionStartSettings': {
                                    'FollowPoint': 'END',
                                    'ReferenceActionName': custom_selection
                        },
            
                            }
                        },
                    ]
                }
            )
            #print(json.dumps(response))
        except Exception as e:
            print("Error creating Schedule Action")
            print(e)
    return itemstoreschedule