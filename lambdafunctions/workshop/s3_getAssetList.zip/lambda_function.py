import json
import boto3
import datetime

def lambda_handler(event, context):
    
    account = str(event['awsaccount'])

    if account is "master":
        s3 = boto3.resource('s3')
    else:
        sts_connection = boto3.client('sts')
        acct_b = sts_connection.assume_role(
            RoleArn="arn:aws:iam::"+account+":role/AssumeRoleLambda",
            RoleSessionName="cross_acct_lambda"
        )
        
        ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
        SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
        SESSION_TOKEN = acct_b['Credentials']['SessionToken']
        
        s3 = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN,)
    
    assets = dict() # dictionary
    assets = [] # array/list
    bucket = event['bucket']

    bucket = s3.Bucket(bucket)
    for obj in bucket.objects.all():
        if ".mp4" in str(obj.key):
            #assets.update({'name' : obj.size})
            #assets.append(obj.key)
            assets.append({'name' : obj.key.rsplit('/', 1)[-1], 'size' : obj.size, 'key' : obj.key})
            #assets.append(obj.key) 
    return(assets)