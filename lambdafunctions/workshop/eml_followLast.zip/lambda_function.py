import json
import boto3
import datetime
import random

# Step 1 : Get current schedule
# Step 2 : isolate last item in schedule
# Step 3 : API call to follow last item in schedule

def lambda_handler(event, context):
    
    account = str(event['awsaccount'])

    if account is "master":
        client = boto3.client('medialive')
    else:
        sts_connection = boto3.client('sts')
        acct_b = sts_connection.assume_role(
            RoleArn="arn:aws:iam::"+account+":role/AssumeRoleLambda",
            RoleSessionName="cross_acct_lambda"
        )
        
        ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
        SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
        SESSION_TOKEN = acct_b['Credentials']['SessionToken']
        
        client = boto3.client('medialive', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN,)
    
    channelid = event['channelid']
    maxresults = int(event['maxresults'])

    try:
        response = client.describe_schedule(
        ChannelId=channelid,
        MaxResults=200
        )
    except Exception as e:
        print(e)
    #custom_selection = response['ScheduleActions'][-1]['ActionName']
    schedule = []

    for action in response['ScheduleActions']:
        if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
            schedule.append(action['ActionName'])

    custom_selection = schedule[-1]
    
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    
    bucket = event['bucket']
    inputkey = str(event['input']).replace("%2F","/")
    actionname = inputkey.rsplit('/', 1)[-1] + "_" + timestring
    inputurl = bucket + "/" + inputkey
    response = client.list_inputs(MaxResults=maxresults)
    inputs = []
    for channel in response['Inputs']:
        attachedchannelid = str(channel['AttachedChannels'])
        if channelid in attachedchannelid:
            if "DYNAMIC" in channel['InputSourceType']:
                inputs.append(channel['Name'])
    if len(inputs) is 0:
        return "ERROR: No dynamic inputs attached to this channel!"
    attacheddynamicinputs = len(inputs) -1
    inputattachref = str(inputs[random.randint(0,attacheddynamicinputs)])

    client = boto3.client('medialive')
    try:
        response = client.batch_update_schedule(
            ChannelId=channelid,
            Creates={
                'ScheduleActions': [
                    {
                        'ActionName': actionname,
                        'ScheduleActionSettings': {
                            'InputSwitchSettings': {
                                'InputAttachmentNameReference': inputattachref,
                                'UrlPath': [
                                    inputurl,inputurl
                                ]
                            },
                        },
                        'ScheduleActionStartSettings': {
                            'FollowModeScheduleActionStartSettings': {
                                'FollowPoint': 'END',
                                'ReferenceActionName': custom_selection
                    },
        
                        }
                    },
                ]
            }
        )
        print(json.dumps(response))
    except Exception as e:
        print("Error creating Schedule Action")
        print(e)
    return response
