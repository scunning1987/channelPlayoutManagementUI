import json
import boto3
import datetime
import random
import time

def lambda_handler(event, context):
    
    # global vars:
    # maxresults, channelid, bucket, input/file, awsaccount, follow (actiontofollow), functiontorun
    channelid = str(event['channelid'])
    maxresults = int(event['maxresults'])
    awsacc = event['awsaccount']
    #input = str(event['input'])
    inputkey = event['input'].replace("%2F","/")
    functiontorun = str(event['functiontorun'])
    follow = str(event['follow'])
    bucket = str(event['bucket'])

    ### Below code will get access & secret key if executing into another account

    if awsacc == "master":
        client = boto3.client('medialive')
        s3 = boto3.resource('s3')
    else:
        sts_connection = boto3.client('sts')
        acct_b = sts_connection.assume_role(
            RoleArn="arn:aws:iam::"+awsacc+":role/AWSLambdaAccessToS3AndEML",
            RoleSessionName="cross_acct_lambda"
        )
        
        ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
        SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
        SESSION_TOKEN = acct_b['Credentials']['SessionToken']
        
        client = boto3.client('medialive', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN,)
        s3 = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN,)

    # add the below vars inside the batch_update functions
    #   time = datetime.datetime.utcnow()
    #   timestring = time.strftime('%Y-%m-%dT%H%M%SZ')

    ### Function Start : list_inputs ###
    def list_inputs(type):
        print("function:list_inputs")
        response = client.list_inputs(MaxResults=maxresults)
    
        fileinputs = []
        liveinputs = []
        liveinputslist = []
        for channel in response['Inputs']:
            attachedchannelid = str(channel['AttachedChannels'])
            if channelid in attachedchannelid:
                    if str(channel['Type']) in ('RTMP_PUSH', 'UDP_PUSH', 'RTP_PUSH', 'RTMP_PULL', 'URL_PULL', 'MEDIACONNECT', 'INPUT_DEVICE') or str(channel['InputSourceType']) == 'STATIC':
                        liveinputs.append({'name' : channel['Name'], 'type' : channel['Type']})
                        liveinputslist.append(channel['Name'])
                    if "DYNAMIC" in channel['InputSourceType']:
                        fileinputs.append(channel['Name'])
        if len(fileinputs) is 0:
            print("ERROR: No dynamic inputs attached to this channel!")
        if len(liveinputs) is 0:
            print("ERROR: No live inputs attached to this channel!")
        
        inputdict = dict()
        inputdict['file'] = fileinputs
        inputdict['live'] = liveinputs
        inputdict['livelist'] = liveinputslist
        if type == "livedashboard": # call originated from dashboard , must return response in json list only
            return liveinputs
        else: # dictionary return
            return inputdict

    ### Function End : list_inputs ###

    ### Function Start : describe_channel ###
    def describe_channel():
        try:
            response = client.describe_channel(
            ChannelId=channelid
            )
            #print(json.dumps(response))
        except Exception as e:
            print(e)
        current_active = response['PipelineDetails'][0]['ActiveInputSwitchActionName']
        return current_active

    ### Function End : describe_channel ###

    ### Function Start : describe_schedule ###

    def describe_schedule(inputs, currentaction, follow):
        response = client.describe_schedule(ChannelId=channelid,MaxResults=maxresults)
        # getting list to reschedule
        schedule = []
        actionpaths = []
        dashboardlist = []
        scheduledic = dict()
        
        if currentaction == "Initial Channel Input":
            dashboardlist.append({'actionname' : 'Initial Channel Input', 'actionrefname' : 'Initial Channel Input'})
            
            scheduledic['dashboardlist'] = dashboardlist
            scheduledic['itemstoreschedule'] = []
            scheduledic['itemstodelete'] = []
            return scheduledic

        for action in response['ScheduleActions']:
            if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
                schedule.append(action['ActionName'])
                if str(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']) in inputs['file']:
                    actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0])
                    dashboardlist.append({'actionname' : action['ActionName'], 'actionrefname' : action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']})
                elif str(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']) in str(inputs['live']):
                    actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference'])
                    dashboardlist.append({'actionname' : action['ActionName'], 'actionrefname' : action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']})
        
        scheduledic['lastaction'] = schedule[-1]

        if currentaction == "followlast":
            return scheduledic
        else:

            itemstoreschedule = []
            itemstodelete = []
            dashboardlistsub = []
    
            if len(schedule) is 0:
                itemstoreschedule = []
            else:
                if follow == "true":
                    indexofactive = schedule.index(currentaction) + 1
                    listlength = len(schedule) + 1
                else:
                    indexofactive = schedule.index(currentaction)
                    listlength = len(schedule)
                # CREATE SUB ARRAY FOR ACTIONS TO REPOPULATE
                itemstoreschedule = actionpaths[indexofactive:listlength]
                itemstodelete = schedule[indexofactive:listlength]
                dashboardlistsub = dashboardlist[indexofactive:listlength]
    
            scheduledic['itemstoreschedule'] = itemstoreschedule
            scheduledic['itemstodelete'] = itemstodelete
            scheduledic['dashboardlist'] = dashboardlistsub
            return scheduledic

    ### Function End : describe_schedule ###

    ### Function Start : batch_update ###
    def batch_update(type, followaction, inputs, inputfile):
        # types ; immediate, follow, live
        # vars
        time = datetime.datetime.utcnow()
        timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
        actionname = inputfile.rsplit('/', 1)[-1] + "_" + str(random.randint(100,999)) + "_" + timestring
        inputurl = bucket + "/" + str(inputfile)
        if type == "live":
            attacheddynamicinputs = 1
        else:
            attacheddynamicinputs = len(inputs['file']) -1
            inputattachref = str(inputs['file'][random.randint(0,attacheddynamicinputs)])

        if type == "immediate":
            try:
                response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref,
                                    'UrlPath': [
                                        inputurl,inputurl
                                    ]
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'ImmediateModeScheduleActionStartSettings': {}
            
                            }
                        },
                    ]
                }
                )
                print(json.dumps(response))
            except Exception as e:
                print("Error creating Schedule Action")
                print(e)
            return response 

        elif type == "follow":
            response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref,
                                    'UrlPath': [
                                        inputurl,inputurl
                                    ]
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'FollowModeScheduleActionStartSettings': {
                                    'FollowPoint': 'END',
                                    'ReferenceActionName': followaction
                        },
            
                            }
                        },
                    ]
                }
            )
            return response
            
        else: # this assumes the type is now LIVE immediate
            try:
                response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputkey
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'ImmediateModeScheduleActionStartSettings': {}
                            }
                        },
                    ]
                }
                )
                print(json.dumps(response))
            except Exception as e:
                print("Error creating Schedule Action")
                print(e)
            return response

    ### Function End : batch_update ###

    ### Function Start : batch_udpate delete ###
    def batch_update_delete(itemstodelete):
        deletedict = dict()
        deletedict["ActionNames"] = itemstodelete
        
        # DELETE Items in subarray
        #actionstodelete = ' , '.join('"' + action + '"' for action in actions[0:deleteindex])
        #return actionstodelete
        try:
            response = client.batch_update_schedule(ChannelId=channelid,Deletes=deletedict)
        except Exception as e:
            return e
    ### Function End : batch_udpate delete ###
    
    ### Function Start : SCTE35 inject ###
    
    def scteInject():
        event_id = 1001 #id of your choice
        duration = int(event['duration']) * 90000 #duration of ad (10 sec* 90000 Hz ticks)
        time = datetime.datetime.utcnow()
        timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
        actionname = "SCTE35_duration_" + str(event['duration']) + "_seconds_" + timestring
        try:
            response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions':[
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'Scte35SpliceInsertSettings': {
                                    'SpliceEventId': event_id,
                                    'Duration': duration
                                }
                            },
                            'ScheduleActionStartSettings': { 
                                'ImmediateModeScheduleActionStartSettings': {}
                            }
                        }
                        ]
                }
                )
        except Exception as e:
            print("Error creating Schedule Action")
            print(e)
        return response

    ### Function End : SCTE35 inject ###
    
    #response = client.list_inputs(MaxResults=maxresults)
    #liveinputs = []
    #for channel in response['Inputs']:
    #        attachedchannelid = str(channel['AttachedChannels'])
    #        if channelid in attachedchannelid:
    #            liveinputs.append(channel)
    #return liveinputs
    
    def immediateSwitch():
        inputs = list_inputs("dictionary") # return dictionary : file, live, livelist
        currentaction = describe_channel() # return string of current running action
        itemstoreplace = describe_schedule(inputs, currentaction, "true") # return dictionary : *itemstoreschedule*, itemstodelete, dashboardlist, lastaction
        batch_update("immediate", "", inputs, inputkey)
        for item in itemstoreplace['itemstoreschedule']:
            lastaction = describe_schedule(inputs, currentaction, "false") # return dictionary : itemstoreschedule, itemstodelete, dashboardlist, *lastaction*
            batch_update("follow", lastaction['lastaction'], inputs, item)
        return itemstoreplace
    
    def immediateSwitchLive():
        inputs = list_inputs("dictionary") # return dictionary : file, live, livelist
        return batch_update("live", "", inputs, inputkey)

    def getSchedule():
        inputs = list_inputs("dictionary") # return dictionary : file, live, livelist
        currentaction = describe_channel() # return string of current running action
        schedule = describe_schedule(inputs, currentaction, "false") # return dictionary : itemstoreschedule, itemstodelete, *dashboardlist*, lastaction
        return schedule['dashboardlist']

    def followLast():
        inputs = list_inputs("dictionary") # return dictionary : file, live, livelist
        lastaction = describe_schedule(inputs, "followlast", "true") # return dictionary : itemstoreschedule, itemstodelete, *dashboardlist*, lastaction
        response = batch_update("follow", lastaction['lastaction'], inputs, inputkey)
        return response
    
    def followCustom():
        inputs = list_inputs("dictionary") # return dictionary : file, live, livelist
        itemstoreplace = describe_schedule(inputs, follow, "true") # return dictionary : itemstoreschedule, itemstodelete, *dashboardlist*, lastaction
        batch_update_delete(itemstoreplace['itemstodelete'])
        batch_update("follow", follow, inputs, inputkey)
        for item in itemstoreplace['itemstoreschedule']:
            lastaction = describe_schedule(inputs, "followlast", "false") # return dictionary : itemstoreschedule, itemstodelete, dashboardlist, *lastaction*
            batch_update("follow", lastaction['lastaction'], inputs, item)
        return itemstoreplace
    
    def followCurrent():
        inputs = list_inputs("dictionary") # return dictionary : *file*, live, livelist
        currentaction = describe_channel() # return string of current running action
        itemstoreplace = describe_schedule(inputs, currentaction, "true") # return dictionary : *itemstoreschedule*, itemstodelete, dashboardlist, lastaction
        batch_update_delete(itemstoreplace['itemstodelete'])
        batch_update("follow", currentaction, inputs, inputkey)
        for item in itemstoreplace['itemstoreschedule']:
            lastaction = describe_schedule(inputs, "followlast", "false") # return dictionary : itemstoreschedule, itemstodelete, dashboardlist, *lastaction*
            batch_update("follow", lastaction['lastaction'], inputs, item)
        return itemstoreplace
    
    def getLiveInputs():
        inputs = list_inputs("dictionary") # return dictionary : file, live, *livelist*
        return inputs['live']
    
    def s3GetAssetList():
        assets = dict() # dictionary
        assets = [] # array/list
        bucket = event['bucket']
    
        bucket = s3.Bucket(bucket)
        for obj in bucket.objects.all():
            if ".mp4" in str(obj.key):
                #assets.update({'name' : obj.size})
                #assets.append(obj.key)
                assets.append({'name' : obj.key.rsplit('/', 1)[-1], 'size' : obj.size, 'key' : obj.key})
                #assets.append(obj.key) 
        return(assets)
    
    if functiontorun == "getSchedule":
        return getSchedule()
    elif functiontorun == "s3GetAssetList":
        return s3GetAssetList()
    elif functiontorun == "followCurrent":
        return followCurrent()
    elif functiontorun == "followLast":
        return followLast()
    elif functiontorun == "followCustom":
        return followCustom()
    elif functiontorun == "immediateSwitch":
        return immediateSwitch()
    elif functiontorun == "getAttachedInputs":
        return getLiveInputs()
    elif functiontorun == "immediateSwitchLive":
        return immediateSwitchLive()
    elif functiontorun == "scteInject":
        return scteInject()
    else: # return error
        return "invalid functiontorun value sent to function"