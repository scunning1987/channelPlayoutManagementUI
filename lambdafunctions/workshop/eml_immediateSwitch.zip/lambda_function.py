import json
import boto3
import datetime
import random

def lambda_handler(event, context):
    
    awsacc = event['awsaccount']

    if awsacc == "master":
        client = boto3.client('medialive')
    else:
        sts_connection = boto3.client('sts')
        acct_b = sts_connection.assume_role(
            RoleArn="arn:aws:iam::"+awsacc+":role/AWSLambdaAccessToS3AndEML",
            RoleSessionName="cross_acct_lambda"
        )
        
        ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
        SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
        SESSION_TOKEN = acct_b['Credentials']['SessionToken']
        
        client = boto3.client('medialive', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN,)
    
    channelid = event['channelid']
    bucket = event['bucket']
    maxresults = int(event['maxresults'])
    inputkey = event['input'].replace("%2F","/")
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    actionname = inputkey.rsplit('/', 1)[-1] + "_" + timestring
    inputurl = bucket + "/" + str(inputkey)
    
    response = client.list_inputs(MaxResults=maxresults)
    inputs = []
    for channel in response['Inputs']:
        attachedchannelid = str(channel['AttachedChannels'])
        if channelid in attachedchannelid:
            if "DYNAMIC" in channel['InputSourceType']:
                inputs.append(channel['Name'])
    if len(inputs) is 0:
        return "ERROR: No dynamic inputs attached to this channel!"
    attacheddynamicinputs = len(inputs) -1
    inputattachref = str(inputs[random.randint(0,attacheddynamicinputs)])


    # GET ACTIVE ACTION
    try:
        response = client.describe_channel(
        ChannelId=channelid
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)
    current_active = response['PipelineDetails'][0]['ActiveInputSwitchActionName']

    # Get GET EML SCHEDULE
    try:
        response = client.describe_schedule(
        ChannelId=channelid,
        MaxResults=maxresults
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)
    schedule = []
    actionpaths = []
    scheduledic = dict()

    for action in response['ScheduleActions']:
        if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
            schedule.append(action['ActionName'])
            if str(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']) in inputs:
                actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0])
            else:
                actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference'])
    # FIND WHERE ACTIVE ACTION IS IN CURRENT SCHEDULE
    # current_active (name of action)
    # schedule (list containing schedule of actions)
    # actionpaths (urls of actions to reassign) - this list needs to be used after the immediate put is complete
    itemstoreschedule = []
    if len(schedule) is 0:
        itemstoreschedule = []
    else:
        indexofactive = schedule.index(current_active) +1
        listlength = len(schedule) 
        # CREATE SUB ARRAY FOR ACTIONS TO REPOPULATE
        #return("Active item is : " + str(indexofactive) + "of" + str(listlength) + " items" + str(itemstoreschedule))
        itemstoreschedule = actionpaths[indexofactive:listlength] 

    # try PUT for file to start immediate
    try:
        response = client.batch_update_schedule(
            ChannelId=channelid,
            Creates={
                'ScheduleActions': [
                    {
                        'ActionName': actionname,
                        'ScheduleActionSettings': {
                            'InputSwitchSettings': {
                                'InputAttachmentNameReference': inputattachref,
                                'UrlPath': [
                                    inputurl,inputurl
                                ]
                            },
                        },
                        'ScheduleActionStartSettings': {
                            'ImmediateModeScheduleActionStartSettings': {}
        
                        }
                    },
                ]
            }
        )
        print(json.dumps(response))
    except Exception as e:
        print("Error creating Schedule Action")
        print(e)
    # For each file left in list DOOOO
    # list variable name : itemstoreschedule
    
    for item in itemstoreschedule:
        time = datetime.datetime.utcnow()
        timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
        actionname = item.rsplit('/', 1)[-1] + "_" + timestring
        inputattachref = str(inputs[random.randint(0,attacheddynamicinputs)])
        inputurl = item

        # API Get schedule last action [swith action]
        
        try:
            response = client.describe_schedule(
            ChannelId=channelid,
            MaxResults=200
            )
        except Exception as e:
            print(e)
        custom_selection = response['ScheduleActions'][-1]['ActionName']
        
        # API Append Schedule with follow PUT
        
        try:
            response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref,
                                    'UrlPath': [
                                        inputurl,inputurl
                                    ]
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'FollowModeScheduleActionStartSettings': {
                                    'FollowPoint': 'END',
                                    'ReferenceActionName': custom_selection
                        },
            
                            }
                        },
                    ]
                }
            )
            print(json.dumps(response))
        except Exception as e:
            print("Error creating Schedule Action")
            print(e)
    return itemstoreschedule