import json
import boto3
import datetime
import random

def lambda_handler(event, context):
    
    
    # function will have multiple parts : getInputs, immediateSwitch
    
    channelid = str(event['channelid'])
    maxresults = int(event['maxresults'])
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    awsacc = event['awsaccount']
    input = str(event['input'])
    actionname = input + "_LIVE_" + timestring
    inputattachref = input
    
    if awsacc == "master":
        client = boto3.client('medialive')
    else:
        sts_connection = boto3.client('sts')
        acct_b = sts_connection.assume_role(
            RoleArn="arn:aws:iam::"+awsacc+":role/AWSLambdaAccessToS3AndEML",
            RoleSessionName="cross_acct_lambda"
        )
        
        ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
        SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
        SESSION_TOKEN = acct_b['Credentials']['SessionToken']
        
        client = boto3.client('medialive', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN,)

    ### start getinputs function
    
    def getinputs(type):
        print("getinputs")
        response = client.list_inputs(MaxResults=maxresults)
    
    
        fileinputs = []
        liveinputs = []
        liveinputslist = []
        for channel in response['Inputs']:
            attachedchannelid = str(channel['AttachedChannels'])
            if channelid in attachedchannelid:
                    if str(channel['Type']) in ('RTMP_PUSH', 'UDP_PUSH', 'RTP_PUSH', 'RTMP_PULL', 'URL_PULL', 'MEDIACONNECT'):
                        liveinputs.append({'name' : channel['Name'], 'type' : channel['Type']})
                        liveinputslist.append(channel['Name'])
                    if "DYNAMIC" in channel['InputSourceType']:
                        fileinputs.append(channel['Name'])
        inputdict = dict()
        inputdict['file'] = fileinputs
        inputdict['live'] = liveinputs
        inputdict['livelist'] = liveinputslist
        if type == "dashboard": # call originated from dashboard , must return response in json list only
            return liveinputs
        else: # dictionary return
            return inputdict
    
    ### end getinputs function
    ### start immediateswitchfunction
    
    def immediateswitch(live):
        print("immediateswitch")
        #
        # try PUT for file to start immediate
        # 
        # need variables for inputattachref and actionname (should both be derivitaves of the selected input)
        #
        try:
            response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'ImmediateModeScheduleActionStartSettings': {}
            
                            }
                        },
                    ]
                }
            )
            print(json.dumps(response))
        except Exception as e:
            print("Error creating Schedule Action")
            print(e)
        return response
    
    ### end immediateswitchfunction
    
    ### start getschedulefunction
    
    def getSchedule(type, inputs):
        # get active input first
        # get all schedule items after current active action
        # GET ACTIVE ACTION
        try:
            response = client.describe_channel(
            ChannelId=channelid
            )
            #print(json.dumps(response))
        except Exception as e:
            print(e)
        current_active = response['PipelineDetails'][0]['ActiveInputSwitchActionName']
        
        # Get GET EML SCHEDULE
        try:
            response = client.describe_schedule(
            ChannelId=channelid,
            MaxResults=maxresults
            )
            #print(json.dumps(response))
        except Exception as e:
            print(e)

        # get last switch action for append
        if type == "getlast":
            schedule = []
            for action in response['ScheduleActions']:
                if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
                    schedule.append(action['ActionName'])
        
            lastaction = schedule[-1]
            return lastaction

        elif type == "itemstoreschedule":
            # getting list to reschedule
            schedule = []
            actionpaths = []
            scheduledic = dict()
    
            for action in response['ScheduleActions']:
                if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
                    schedule.append(action['ActionName'])
                    if str(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']) in inputs['file']:
                        actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['UrlPath'][0])
                    elif str(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']) in str(inputs['live']):
                        #actionpaths.append(action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference'])
                        actionpaths.append("live")
            
            itemstoreschedule = []
            if len(schedule) is 0:
                itemstoreschedule = []
            else:
                indexofactive = schedule.index(current_active) +1
                listlength = len(schedule) 
                # CREATE SUB ARRAY FOR ACTIONS TO REPOPULATE
                itemstoreschedule = actionpaths[indexofactive:listlength]
            return itemstoreschedule

    ### end getschedulefunction
    
    ### start updateschedulefunction

    def updateschedule(item, inputs, actiontofollow):
        time = datetime.datetime.utcnow()
        timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
        
        actionrefname = item.rsplit('/', 1)[-1]
        
        if actionrefname in str(inputs): # this is a live action
            actionname = actionrefname + "_" + timestring
            inputattachref = item
            actiontofollow = actiontofollow
            
            try:
                response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'FollowModeScheduleActionStartSettings': {
                                    'FollowPoint': 'END',
                                    'ReferenceActionName': actiontofollow
                        },
            
                            }
                        },
                    ]
                }
                )
                print(json.dumps(response))
            except Exception as e:
                print("Error creating Schedule Action")
                print(e)
        
        else: # these are dynamic inputs
        
            actionname = actionrefname + "_" + timestring
            attacheddynamicinputs = inputs['file']
            inputattachref = str(inputs[random.randint(0,attacheddynamicinputs)])
            inputurl = item
            actiontofollow = actiontofollow
            
            try:
                response = client.batch_update_schedule(
                ChannelId=channelid,
                Creates={
                    'ScheduleActions': [
                        {
                            'ActionName': actionname,
                            'ScheduleActionSettings': {
                                'InputSwitchSettings': {
                                    'InputAttachmentNameReference': inputattachref,
                                    'UrlPath': [
                                        inputurl,inputurl
                                    ]
                                },
                            },
                            'ScheduleActionStartSettings': {
                                'FollowModeScheduleActionStartSettings': {
                                    'FollowPoint': 'END',
                                    'ReferenceActionName': actiontofollow
                        },
            
                            }
                        },
                    ]
                }
                )
                print(json.dumps(response))
            except Exception as e:
                print("Error creating Schedule Action")
                print(e)

    ### end updateschedulefunction

    #inputs = getinputs("dictionary")
    #itemstoreschedule = getSchedule("itemstoreschedule", inputs)
    #immediateswitch("live")
    #for item in itemstoreschedule: 
    #    actiontofollow = getSchedule("getlast", "na")
    #    updateschedule(item, inputs, actiontofollow)        
    #return "done"

    ## function selection
    if str(event['function']) == "getinputs":
        return getinputs("dashboard")
    elif str(event['function']) == "immediateswitch":
        # inputs = getinputs("dictionary")
        # itemstoreschedule = getSchedule(inputs)
        return immediateswitch("live")
        # for item in itemstoreschedule: 
        #   actiontofollow = getSchedule("getlast", "na")
        #   updateschedule(item, inputs, actiontofollow)