import json
import boto3

def lambda_handler(event, context):
    client = boto3.client('medialive')
    channelid = event['channelid']
    maxresults = int(event['maxresults'])

    # GET ACTIVE ACTION
    try:
        response = client.describe_channel(
        ChannelId=channelid
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)
    current_active = response['PipelineDetails'][0]['ActiveInputSwitchActionName']

    # Get GET EML SCHEDULE
    try:
        response = client.describe_schedule(
        ChannelId=channelid,
        MaxResults=maxresults
        )
        #print(json.dumps(response))
    except Exception as e:
        print(e)

    schedule = []
    actionpaths = []

    for action in response['ScheduleActions']:
        if "InputSwitchSettings" in action['ScheduleActionSettings']: # This filters out the input switch actions only
            schedule.append(action['ActionName'])
            actionpaths.append({'actionname' : action['ActionName'], 'actionrefname' : action['ScheduleActionSettings']['InputSwitchSettings']['InputAttachmentNameReference']})
    # FIND WHERE ACTIVE ACTION IS IN CURRENT SCHEDULE
    # current_active (name of action)
    # schedule (list containing schedule of actions)
    # actionpaths (urls of actions to reassign) - this list needs to be used after the immediate put is complete

    if len(schedule) is 0:
        return current_active
    else:
        indexofactive = schedule.index(current_active)
        listlength = len(schedule)

        # CREATE SUB ARRAY FOR ACTIONS TO DISPLAY
        #return("Active item is : " + str(indexofactive) + "of" + str(listlength) + " items" + str(itemstoreschedule))
        itemstodisplay = actionpaths[indexofactive:listlength]
        return itemstodisplay