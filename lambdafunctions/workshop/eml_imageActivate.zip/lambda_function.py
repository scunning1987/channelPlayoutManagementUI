import json
import boto3 
import datetime
import random

def lambda_handler(event, context):
    opacity = int(event['opacity'])
    height = int(event['height'])
    width = int(event['width'])
    posy = int(event['posy'])
    posx = int(event['posx'])
    duration = int(event['duration'])
    channelid = event['channelid']
    bucket = event['bucket']
    inputkey = event['input'].replace("%2F","/")
    time = datetime.datetime.utcnow()
    timestring = time.strftime('%Y-%m-%dT%H%M%SZ')
    actionname = inputkey.rsplit('/', 1)[-1] + "_overlay_" + timestring
    inputurl = "s3://" + bucket + "/" + str(inputkey)
    layer = random.randint(0,7)
    client = boto3.client('medialive')
    try:
        response = client.batch_update_schedule(
            ChannelId=channelid,
            Creates={
                'ScheduleActions': [
                    {
                        'ActionName': actionname,
                        'ScheduleActionSettings': {
                          'StaticImageActivateSettings': {
                            'Duration': duration,
                            'FadeIn': 0,
                            'FadeOut': 0,
                            'Height': height,
                            'Image': {
                              'Uri': inputurl,
                            },
                        'ImageX': posx,
                        'ImageY': posy,
                        'Layer': layer,
                        'Opacity': opacity,
                        'Width': width
                    },
                        },
                        'ScheduleActionStartSettings': {
                            'ImmediateModeScheduleActionStartSettings': {}
        
                        }
                    },
                ]
            }
        )
    #print(json.dumps(response))
    except Exception as e:
        print("Error creating Schedule Action")
        print(e)
    return response