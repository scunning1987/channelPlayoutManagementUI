import json
import boto3
import datetime

def lambda_handler(event, context):
    assets = dict() # dictionary
    assets = [] # array/list
    bucket = event['bucket']
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket)
    for obj in bucket.objects.all():
        if ".mp4" in str(obj.key):
            #assets.update({'name' : obj.size})
            #assets.append(obj.key)
            assets.append({'name' : obj.key.rsplit('/', 1)[-1], 'size' : obj.size, 'key' : obj.key})
            #assets.append(obj.key) 
    return(assets)